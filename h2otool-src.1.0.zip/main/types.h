#ifndef TYPES_H_
#define TYPES_H_

typedef unsigned int uint32;
typedef signed int int32;
typedef unsigned short uint16;
typedef unsigned char uint8;

#endif /*TYPES_H_*/
