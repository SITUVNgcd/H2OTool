#ifndef DEBUG_H_
#define DEBUG_H_

void dprintf(const char *format, ...);

#endif /*DEBUG_H_*/
